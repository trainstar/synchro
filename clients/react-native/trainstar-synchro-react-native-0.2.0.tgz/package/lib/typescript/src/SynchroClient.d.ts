import type { Row, ExecResult, BatchResult, SQLStatement, ColumnDef, TableOptions, Transaction, CheckpointMode, SyncStatus, ConflictEvent, SynchroConfig, Unsubscribe } from './types';
export declare class SynchroClient {
    private readonly native;
    private readonly config;
    private authSubscription;
    constructor(config: SynchroConfig);
    initialize(): Promise<void>;
    query(sql: string, params?: unknown[]): Promise<Row[]>;
    queryOne(sql: string, params?: unknown[]): Promise<Row | null>;
    execute(sql: string, params?: unknown[]): Promise<ExecResult>;
    executeBatch(statements: SQLStatement[]): Promise<BatchResult>;
    writeTransaction<T>(callback: (tx: Transaction) => Promise<T>): Promise<T>;
    readTransaction<T>(callback: (tx: Transaction) => Promise<T>): Promise<T>;
    createTable(name: string, columns: ColumnDef[], options?: TableOptions): Promise<void>;
    alterTable(name: string, addColumns: ColumnDef[]): Promise<void>;
    createIndex(table: string, columns: string[], unique?: boolean): Promise<void>;
    onChange(tables: string[], callback: () => void): Unsubscribe;
    watch(sql: string, params: unknown[] | undefined, tables: string[], callback: (rows: Row[]) => void): Unsubscribe;
    checkpoint(mode?: CheckpointMode): Promise<void>;
    close(): Promise<void>;
    getPath(): Promise<string>;
    pendingChangeCount(): Promise<number>;
    start(): Promise<void>;
    stop(): Promise<void>;
    syncNow(): Promise<void>;
    onStatusChange(callback: (status: SyncStatus) => void): Unsubscribe;
    onConflict(callback: (event: ConflictEvent) => void): Unsubscribe;
    onSnapshotRequired(handler: () => Promise<boolean>): Unsubscribe;
}
//# sourceMappingURL=SynchroClient.d.ts.map