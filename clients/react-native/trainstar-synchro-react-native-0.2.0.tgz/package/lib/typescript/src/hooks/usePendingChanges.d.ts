import type { SynchroClient } from '../SynchroClient';
export declare function usePendingChanges(client: SynchroClient, pollInterval?: number): number;
//# sourceMappingURL=usePendingChanges.d.ts.map