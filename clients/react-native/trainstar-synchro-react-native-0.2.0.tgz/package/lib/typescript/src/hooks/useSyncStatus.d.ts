import type { SynchroClient } from '../SynchroClient';
import type { SyncStatus } from '../types';
export declare function useSyncStatus(client: SynchroClient): SyncStatus;
//# sourceMappingURL=useSyncStatus.d.ts.map