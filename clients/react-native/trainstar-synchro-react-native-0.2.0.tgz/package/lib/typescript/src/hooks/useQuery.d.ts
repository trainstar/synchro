import type { SynchroClient } from '../SynchroClient';
import type { Row } from '../types';
import type { SynchroError } from '../errors';
interface UseQueryResult {
    data: Row[];
    loading: boolean;
    error: SynchroError | null;
    refresh: () => void;
}
export declare function useQuery(client: SynchroClient, sql: string, params?: unknown[], tables?: string[]): UseQueryResult;
export {};
//# sourceMappingURL=useQuery.d.ts.map