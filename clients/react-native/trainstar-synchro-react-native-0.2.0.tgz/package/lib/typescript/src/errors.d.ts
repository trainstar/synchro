export declare class SynchroError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare class NotConnectedError extends SynchroError {
    constructor();
}
export declare class SchemaNotLoadedError extends SynchroError {
    constructor();
}
export declare class TableNotSyncedError extends SynchroError {
    readonly table: string;
    constructor(table: string);
}
export declare class UpgradeRequiredError extends SynchroError {
    readonly currentVersion: string;
    readonly minimumVersion: string;
    constructor(currentVersion: string, minimumVersion: string);
}
export declare class SchemaMismatchError extends SynchroError {
    readonly serverVersion: number;
    readonly serverHash: string;
    constructor(serverVersion: number, serverHash: string);
}
export declare class SnapshotRequiredError extends SynchroError {
    constructor();
}
export interface PushResultItem {
    recordID: string;
    table: string;
    status: string;
    message?: string;
}
export declare class PushRejectedError extends SynchroError {
    readonly results: PushResultItem[];
    constructor(results: PushResultItem[]);
}
export declare class NetworkError extends SynchroError {
    constructor(message: string);
}
export declare class ServerError extends SynchroError {
    readonly status: number;
    constructor(status: number, message: string);
}
export declare class DatabaseError extends SynchroError {
    constructor(message: string);
}
export declare class InvalidResponseError extends SynchroError {
    constructor(message: string);
}
export declare class AlreadyStartedError extends SynchroError {
    constructor();
}
export declare class NotStartedError extends SynchroError {
    constructor();
}
export declare class TransactionTimeoutError extends SynchroError {
    constructor();
}
export declare function mapNativeError(error: unknown): SynchroError;
//# sourceMappingURL=errors.d.ts.map