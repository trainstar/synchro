import type { TurboModule } from 'react-native';
import type { EventEmitter } from 'react-native/Libraries/Types/CodegenTypes';
type StatusEvent = {
    status: string;
    retryAt: string | null;
};
type ConflictEvent = {
    table: string;
    recordID: string;
    clientDataJson: string | null;
    serverDataJson: string | null;
};
type AuthRequestEvent = {
    requestID: string;
};
type SnapshotRequiredEvent = {
    requestID: string;
};
type ChangeEvent = {
    observerID: string;
};
type QueryResultEvent = {
    observerID: string;
    rowsJson: string;
};
export interface Spec extends TurboModule {
    initialize(config: {
        dbPath: string;
        serverURL: string;
        clientID: string;
        platform: string;
        appVersion: string;
        syncInterval: number;
        pushDebounce: number;
        maxRetryAttempts: number;
        pullPageSize: number;
        pushBatchSize: number;
        snapshotPageSize: number;
        seedDatabasePath?: string;
    }): Promise<void>;
    close(): Promise<void>;
    getPath(): Promise<string>;
    query(sql: string, paramsJson: string): Promise<string>;
    queryOne(sql: string, paramsJson: string): Promise<string | null>;
    execute(sql: string, paramsJson: string): Promise<{
        rowsAffected: number;
    }>;
    executeBatch(statementsJson: string): Promise<{
        totalRowsAffected: number;
    }>;
    beginWriteTransaction(): Promise<string>;
    beginReadTransaction(): Promise<string>;
    txQuery(txID: string, sql: string, paramsJson: string): Promise<string>;
    txQueryOne(txID: string, sql: string, paramsJson: string): Promise<string | null>;
    txExecute(txID: string, sql: string, paramsJson: string): Promise<{
        rowsAffected: number;
    }>;
    commitTransaction(txID: string): Promise<void>;
    rollbackTransaction(txID: string): Promise<void>;
    createTable(name: string, columnsJson: string, optionsJson: string | null): Promise<void>;
    alterTable(name: string, columnsJson: string): Promise<void>;
    createIndex(table: string, columns: ReadonlyArray<string>, unique: boolean): Promise<void>;
    addChangeObserver(observerID: string, tables: ReadonlyArray<string>): Promise<void>;
    addQueryObserver(observerID: string, sql: string, paramsJson: string, tables: ReadonlyArray<string>): Promise<void>;
    removeObserver(observerID: string): Promise<void>;
    checkpoint(mode: string): Promise<void>;
    start(): Promise<void>;
    stop(): Promise<void>;
    syncNow(): Promise<void>;
    pendingChangeCount(): Promise<number>;
    resolveAuthRequest(requestID: string, token: string): void;
    rejectAuthRequest(requestID: string, error: string): void;
    resolveSnapshotRequest(requestID: string, approved: boolean): void;
    readonly onStatusChange: EventEmitter<StatusEvent>;
    readonly onConflict: EventEmitter<ConflictEvent>;
    readonly onAuthRequest: EventEmitter<AuthRequestEvent>;
    readonly onSnapshotRequired: EventEmitter<SnapshotRequiredEvent>;
    readonly onChange: EventEmitter<ChangeEvent>;
    readonly onQueryResult: EventEmitter<QueryResultEvent>;
    addListener(eventName: string): void;
    removeListeners(count: number): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeSynchro.d.ts.map